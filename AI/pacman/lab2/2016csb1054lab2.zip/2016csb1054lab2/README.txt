Submitted by: 	Rishabh Singh
Roll No.:		2016csb1054
Course:			CS-512
=================================

1. How to compile and run this program

	Ques 1 :

		python2 tsp.py <filename>
			<filename> is the name of the file in which we have coordinates of the city.

	Ques 2 :

		python2 simulatedAnneling.py <filename>
			<filename> is the name of the file in which we have coordinates of the city.

	Ques 4 to 8

		python2 autograder.py

====================================
Note *** :

	Tested On :
		OS 		: Linux 18.04
		python  : version 2.7
	
	data.txt and data2.txt are for testing Hillclimbing and Simulated Anneling
	


	
